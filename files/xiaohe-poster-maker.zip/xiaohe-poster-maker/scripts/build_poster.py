# -*- coding: utf-8 -*-
"""
校园活动展板生成器（小盒精品校园活动 · 诗词大赛版）
=================================================
结合技能内置「源文件」（无字山水底板 + 小盒品牌VI + 3D布克IP），
把文字矢量重绘后合成印刷级展板。放大不糊（文字为矢量，背景高质量放大）。

用法：
  1) 直接改下方 CONFIG 块里的文字/配色，然后运行：
       python3 build_poster.py
  2) 或用外部 JSON 覆盖（不改脚本）：
       python3 build_poster.py --config my.json
     JSON 示例：{"title":"某某县首届中小学诗词大赛","seal_text":"某某教育",
                 "organizers":[["主办单位","某某县教育体育局"],["承办单位","北京小盒科技"]],
                 "location":"陕西 · 宝鸡 · 岐山","date":"2026.10"}
  3) 指定输出目录：
       python3 build_poster.py --out ./output

依赖：Python3 + Pillow（PIL）。中文字体用系统自带（已做 macOS/Windows 兼容）。
"""
import os
import sys
import json
import argparse

try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
except ImportError:
    sys.exit("缺少依赖 Pillow，请先安装：pip3 install pillow")

HERE = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(HERE, "..", "assets")

# ---------------------------------------------------------------------------
# 默认配置（岐山县诗词大赛示例，照此修改即可）
# ---------------------------------------------------------------------------
CONFIG = {
    "output_dir": ".",            # 输出目录
    "file_prefix": "诗词大赛展板",  # 文件名前缀
    "width": 9600, "height": 5400, "dpi": 300,

    # 顶部品牌带
    "seal_text": "岐山教育",        # 红印章文字（2字=单行；4字=两行，如 岐山/教育）
    "show_brand": True,            # 显示「小盒」橙色品牌标志
    "show_activity_vi": True,       # 显示「小盒校园活动」黑色VI文字标

    # 主标题（宋体，书卷气，非楷书）
    "title": "岐山县首届中小学诗词大赛",
    "tagline": "凤鸣岐山  诗润童年",  # 标语

    # 主办/承办/协办（标签, 单位名）
    "organizers": [
        ["主办单位", "岐山县教育体育局"],
        ["承办单位", "北京小盒科技"],
        ["协办单位", "岐山县中心小学"],
    ],

    # 底部
    "location": "陕西 · 宝鸡 · 岐山",
    "date": "2026.10",

    # 配色（RGB）
    "ink": [20, 58, 54],       # 深青墨（标题/正文）
    "teal": [31, 122, 110],    # 小盒青绿
    "gold": [196, 160, 92],    # 暗金装饰
    "red": [196, 52, 48],      # 红印章
    "white": [255, 255, 255],
    "cream": [247, 243, 233],

    # 装饰
    "show_ip": True,           # 左下角 3D布克 IP
    "export_pdf": True,        # 同时导出 300DPI 印刷 PDF
}


# ---------------------------------------------------------------------------
# 跨平台字体解析
# ---------------------------------------------------------------------------
def resolve_fonts():
    """返回 (song_path, song_index, hei_path, hei_index)。优先 macOS，再 Windows。"""
    song_candidates = [
        ("/System/Library/Fonts/Supplemental/Songti.ttc", 0),   # macOS 宋体(粗)
        ("/Library/Fonts/Songti.ttc", 0),
        ("/System/Library/Fonts/STSong.ttf", 0),
        ("C:/Windows/Fonts/simsun.ttc", 0),                      # Windows 宋体
        ("C:/Windows/Fonts/msyh.ttc", 0),                        # Windows 雅黑兜底
    ]
    hei_candidates = [
        ("/System/Library/Fonts/STHeiti Medium.ttc", 0),        # macOS 黑体
        ("/System/Library/Fonts/Supplemental/STHeiti Medium.ttc", 0),
        ("C:/Windows/Fonts/msyh.ttc", 0),                        # Windows 雅黑
        ("C:/Windows/Fonts/simhei.ttf", 0),                      # Windows 黑体
    ]

    def find(cands):
        for p, idx in cands:
            if os.path.exists(p):
                return p, idx
        return None, 0

    s = find(song_candidates)
    h = find(hei_candidates)
    if s[0] is None:
        sys.exit("未找到中文字体（宋体）。macOS 应自带 Songti；Windows 请确认 C:/Windows/Fonts/simsun.ttc 存在。")
    return s[0], s[1], (h[0] or s[0]), (h[1] if h[0] else s[1])


# ---------------------------------------------------------------------------
# 绘图工具
# ---------------------------------------------------------------------------
def draw_spaced(draw, cx, cy, text, fnt, fill, spacing=0):
    """居中绘制带字距的文字。"""
    widths = [draw.textlength(ch, font=fnt) for ch in text]
    total = sum(widths) + spacing * (len(text) - 1)
    x = cx - total / 2
    for ch, w in zip(text, widths):
        draw.text((x + w / 2, cy), ch, font=fnt, fill=fill, anchor="mm")
        x += w + spacing


def place(bg, logo, cx, cy, tw):
    """把 logo 以宽度 tw 居中贴到 bg（RGBA）。"""
    th = int(tw * logo.size[1] / logo.size[0])
    l = logo.resize((tw, th), Image.LANCZOS)
    bg.paste(l, (cx - tw // 2, cy - th // 2), l)


def panel(bg, x0, y0, x1, y1, radius, fill, alpha):
    """半透明圆角面板合成。"""
    layer = Image.new("RGBA", bg.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle([x0, y0, x1, y1], radius=radius, fill=tuple(fill) + (alpha,))
    bg.alpha_composite(layer)


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def build(cfg):
    W, H = cfg["width"], cfg["height"]
    ASSET = lambda *p: os.path.join(ASSET_DIR, *p)
    song_path, song_idx, hei_path, hei_idx = resolve_fonts()

    def font(path, size, index=0):
        return ImageFont.truetype(path, size, index=index)

    ink = tuple(cfg["ink"]); teal = tuple(cfg["teal"]); gold = tuple(cfg["gold"])
    red = tuple(cfg["red"]); white = tuple(cfg["white"]); cream = tuple(cfg["cream"])

    # 背景（无字底板 → 高质量放大）
    bg = (Image.open(ASSET("cleaned_bg.png")).convert("RGB")
          .resize((W, H), Image.LANCZOS).convert("RGBA"))
    d = ImageDraw.Draw(bg)

    # 顶部/底部轻微提亮（不掩盖山水）
    def vscrim(y0, y1, a0, a1):
        mask = Image.new("L", (W, H), 0)
        md = ImageDraw.Draw(mask)
        for y in range(y0, y1):
            t = (y - y0) / (y1 - y0)
            md.line([(0, y), (W, y)], fill=int(a0 + (a1 - a0) * t))
        white_layer = Image.new("RGBA", (W, H), (255, 255, 255, 255))
        bg.paste(white_layer, (0, 0), mask)

    vscrim(0, 1500, 110, 0)
    vscrim(H - 1400, H, 0, 150)

    # ---------- 顶部品牌带 ----------
    # 1) 红印章
    sx, sy = int(W * 0.224), int(H * 0.067)
    seal = int(W * 0.031)
    d.ellipse([sx - seal, sy - seal, sx + seal, sy + seal], fill=red)
    seal_text = cfg["seal_text"]
    sf = font(song_path, int(seal * 0.62), song_idx)
    chars = list(seal_text)
    if len(chars) <= 2:
        draw_spaced(d, sx, sy, seal_text, sf, white, 6)
    else:
        half = (len(chars) + 1) // 2
        draw_spaced(d, sx, sy - seal * 0.26, "".join(chars[:half]), sf, white, 6)
        draw_spaced(d, sx, sy + seal * 0.26, "".join(chars[half:]), sf, white, 6)

    # 2) 小盒 品牌标志（橙）
    if cfg.get("show_brand", True):
        place(bg, Image.open(ASSET("brand-vi", "小盒标志-01.png")).convert("RGBA"),
              int(W * 0.50), int(H * 0.067), int(W * 0.094))
    # 3) 小盒校园活动 VI（黑，浅底规范）
    if cfg.get("show_activity_vi", True):
        place(bg, Image.open(ASSET("activity-vi", "小盒校园活动-黑.png")).convert("RGBA"),
              int(W * 0.79), int(H * 0.067), int(W * 0.156))

    # ---------- 主标题（宋体） ----------
    ty = int(H * 0.404)
    tf = font(song_path, int(W * 0.0625), song_idx)
    draw_spaced(d, W / 2, ty, cfg["title"], tf, ink, spacing=int(W * 0.0048))
    # 标题下金色分隔线 + 菱形
    ly = ty + int(H * 0.087)
    half = int(W * 0.156)
    d.line([(W / 2 - half, ly), (W / 2 + half, ly)], fill=gold, width=int(W * 0.001))
    for dx in (-half, half):
        d.polygon([(W / 2 + dx, ly - int(H * 0.0048)), (W / 2 + dx + int(W * 0.0042), ly),
                   (W / 2 + dx, ly + int(H * 0.0048)), (W / 2 + dx - int(W * 0.0042), ly)], fill=gold)

    # ---------- 标语 ----------
    sl = font(song_path, int(W * 0.026), song_idx)
    draw_spaced(d, W / 2, int(H * 0.552), cfg["tagline"], sl, teal, spacing=int(W * 0.0042))

    # ---------- 主办/承办/协办 ----------
    rows = cfg["organizers"]
    panel(bg, int(W * 0.281), int(H * 0.652), int(W * 0.719), int(H * 0.807),
          int(W * 0.00625), white, 150)
    y0 = int(H * 0.689)
    lab_f = font(hei_path, int(W * 0.0135), hei_idx)
    val_f = font(song_path, int(W * 0.0208), song_idx)
    for i, row in enumerate(rows):
        lab, val = row[0], row[1]
        cy = y0 + i * int(H * 0.052)
        lw = d.textlength(lab, font=lab_f)
        vw = d.textlength(val, font=val_f)
        gap = int(W * 0.0094)
        total = lw + gap + vw
        x = W / 2 - total / 2
        d.text((x + lw / 2, cy), lab, font=lab_f, fill=ink, anchor="mm")
        d.text((x + lw + gap + vw / 2, cy), val, font=val_f, fill=ink, anchor="mm")

    # ---------- 底部地点/日期 ----------
    panel(bg, int(W * 0.3125), int(H * 0.837), int(W * 0.6875), int(H * 0.915),
          int(W * 0.0052), ink, 120)
    bf = font(song_path, int(W * 0.0172), song_idx)
    draw_spaced(d, W / 2, int(H * 0.855), cfg["location"], bf, white, int(W * 0.0021))
    vf = font(song_path, int(W * 0.0156), song_idx)
    draw_spaced(d, W / 2, int(H * 0.890), cfg["date"], vf, white, int(W * 0.0021))

    # ---------- 3D布克 IP ----------
    if cfg.get("show_ip", True):
        ip = Image.open(ASSET("ip", "3D布克-古装站姿1.png")).convert("RGBA")
        glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        gd = ImageDraw.Draw(glow)
        gd.ellipse([int(W * 0.021), int(H * 0.667), int(W * 0.208), int(H * 0.944)],
                   fill=(255, 255, 255, 120))
        glow = glow.filter(ImageFilter.GaussianBlur(int(W * 0.00625)))
        bg.alpha_composite(glow)
        ipw = int(W * 0.135)
        iph = int(ipw * ip.size[1] / ip.size[0])
        ip = ip.resize((ipw, iph), Image.LANCZOS)
        bg.alpha_composite(ip, (int(W * 0.054), int(H * 0.681)))

    # ---------- 输出 ----------
    final = bg.convert("RGB")
    out_dir = cfg.get("output_dir") or "."
    os.makedirs(out_dir, exist_ok=True)
    prefix = cfg.get("file_prefix") or "诗词大赛展板"
    png_path = os.path.join(out_dir, f"{prefix}_{W}x{H}.png")
    final.save(png_path, "PNG", dpi=(cfg["dpi"], cfg["dpi"]))
    # 预览
    prev = final.resize((1600, 900), Image.LANCZOS)
    prev_path = os.path.join(out_dir, "预览.jpg")
    prev.save(prev_path, "JPEG", quality=92)
    # 印刷 PDF（锁定尺寸，无损内嵌）
    if cfg.get("export_pdf", True):
        pdf_path = os.path.join(out_dir, f"{prefix}_印刷源文件_{cfg['dpi']}dpi.pdf")
        final.save(pdf_path, "PDF", resolution=float(cfg["dpi"]))
    else:
        pdf_path = None

    print("PNG :", png_path)
    print("预览:", prev_path)
    if pdf_path:
        print("PDF :", pdf_path)
    return png_path


def main():
    ap = argparse.ArgumentParser(description="校园活动展板生成器")
    ap.add_argument("--config", help="JSON 覆盖配置（可选）")
    ap.add_argument("--out", help="输出目录（覆盖 CONFIG.output_dir）")
    args = ap.parse_args()

    cfg = json.loads(json.dumps(CONFIG))  # 深拷贝
    if args.config and os.path.exists(args.config):
        with open(args.config, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    if args.out:
        cfg["output_dir"] = args.out
    build(cfg)


if __name__ == "__main__":
    main()
