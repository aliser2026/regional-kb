---
name: student-roster-merger
description: This skill should be used when batch-processing school activity rosters (e.g. 数独/Sudoku, 竞赛报名, 培训签到). It cleans per-school xlsx files, normalizes class/grade fields, deletes noisy scoring columns, merges them into one roster, and backfills check codes from a master roster. Triggers when user mentions 花名册、合并花名册、回填校验码、年级映射、班级转年级、删除得分列、roster cleanup, etc.
agent_created: true
---

# Student Roster Merger

## Overview

Batch-process a folder of per-school Excel rosters (`.xlsx`) that share a common 7-column schema (`学校名称 | 班级名称 | 学生姓名 | 得分 | 作答次数 | 作答天数 | 用时(毫秒)`), normalize them, merge into one master file, and optionally backfill a check code column from a separate master roster.

All operations are **deterministic Python** wrappers — no judgment needed once parameters are set.

## Standard Schema (assumed input)

Every input file must have row 1 as header and contain exactly these 7 columns (in this order):

| # | 列名 | 用途 |
|---|---|---|
| 1 | 学校名称 | 保留原值 |
| 2 | 班级名称 | 仅提取年级部分 |
| 3 | 学生姓名 | 保留原值 |
| 4 | 得分 | **删除** |
| 5 | 作答次数 | **删除** |
| 6 | 作答天数 | **删除** |
| 7 | 用时（毫秒） | **删除** |

If the actual schema differs, edit the relevant script's column constants before running.

## Workflow Decision Tree

```
User request
    │
    ├─ "把 X 个分表合并" / "整理花名册"  → run `01_clean_and_merge.py`
    ├─ "班级转年级" / "年级映射成编号"    → run `02_grade_to_code.py`
    ├─ "按主表回填校验码"               → run `03_backfill_check_code.py`
    └─ 复合需求                         → run scripts in order: 01 → 02 → 03
```

## Scripts

All scripts live in `scripts/`. Each is independent and idempotent.

### `scripts/01_clean_and_merge.py` — 字段标准化 + 合并

**做什么:**
- 读取 `INPUT_DIR` 下所有目标 `.xlsx` 文件
- 保留学校名称、班级名称（只保留年级）、学生姓名
- 删除 得分 / 作答次数 / 作答天数 / 用时 四列
- 合并所有数据到一个新文件 `数独花名册_合并结果.xlsx`
- 打印每文件条数和总计

**配置:**
```python
INPUT_DIR  = r"..."   # 待处理文件夹
TARGET_FILES = [...]  # 文件名清单（精确顺序）
OUTPUT_FILE = os.path.join(INPUT_DIR, "数独花名册_合并结果.xlsx")
```

**年级正则:**
```python
GRADE_RE = re.compile(r"(一年级|二年级|...|九年级|初一年级|初二年级|初三年级)")
```

### `scripts/02_grade_to_code.py` — 年级映射成数字

**默认映射规则:**
| 编号 | 原年级 |
|---|---|
| 22 | 一年级、二年级 |
| 23 | 三年级、四年级 |
| 24 | 五年级、六年级 |
| 25 | 七年级、八年级 |

**可改映射:** 直接编辑 `MAP` 字典。

### `scripts/03_backfill_check_code.py` — 主表校验码回填到各分表

**做什么:**
- 从主表（如 `中秋线上数独活动花名册.xlsx`）读 `班级 / 姓名 / 校验码`
- 构建 `(学校, 姓名) -> 校验码` 映射
- 给每个分表追加新列 `校验码`，按学校+姓名双重 key 匹配填入
- 同名学生不会冲突（学校作为唯一化）

**配置:**
```python
ZHONGQIU_FILE = r"..."   # 主表路径
TARGET_FILES = [...]     # 待回填的分表清单
```

## Common Pitfalls

| 现象 | 原因 | 解决 |
|---|---|---|
| `PermissionError` 写文件失败 | Excel / 腾讯文档 host 正在占用该文件 | 关闭宿主预览后重跑，或用 `try/except` 跳过失败文件 |
| `ModuleNotFoundError: openpyxl` | venv 没装 | 装到默认 venv：`C:/Users/20521/.workbuddy/binaries/python/envs/default/Scripts/pip.exe install openpyxl` |
| 学校匹配不到 | 主表中"学校"列实际是平台名（如"小盒科技"），真实学校名在"班级"列 | 用 `class_col` 替换 `school_col` |
| 同名学生被错填 | 只按姓名匹配 | 同时用学校+姓名作为 key |

## Quick Start

```bash
# 1) 准备
C:/Users/20521/.workbuddy/binaries/python/envs/default/Scripts/pip.exe install openpyxl

# 2) 编辑脚本顶部配置（输入文件夹 / 目标文件清单 / 映射规则）

# 3) 按需运行
python scripts/01_clean_and_merge.py
python scripts/02_grade_to_code.py
python scripts/03_backfill_check_code.py
```

## Resources

### scripts/
- `01_clean_and_merge.py` — 字段标准化 + 多表合并
- `02_grade_to_code.py` — 年级 → 编号映射
- `03_backfill_check_code.py` — 主表校验码回填分表
- `run_all.py` — 一键顺序执行 01 → 02 → 03

### references/
- `field-mapping.md` — 默认字段名 / 同义表 / 兼容性说明

### assets/
- `template_roster.xlsx` — 7 列标准空模板，可直接复用为新表头