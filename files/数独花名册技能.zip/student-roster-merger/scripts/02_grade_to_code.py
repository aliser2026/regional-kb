#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Step 2: 年级映射成数字编码

默认规则：
  22 = 一/二年级
  23 = 三/四年级
  24 = 五/六年级
  25 = 七/八年级
"""

from openpyxl import load_workbook

# ============ 配置区 ============
INPUT_FILE = r"待修改文件路径"

# 修改映射请编辑这里
MAP = {
    "一年级": 22, "二年级": 22,
    "三年级": 23, "四年级": 23,
    "五年级": 24, "六年级": 24,
    "七年级": 25, "八年级": 25,
}


def main():
    wb = load_workbook(INPUT_FILE)
    ws = wb.active

    # 检查/重命名表头"班级" -> "年级"
    if ws.cell(row=1, column=2).value == "班级":
        ws.cell(row=1, column=2).value = "年级"
        print("表头: 班级 -> 年级")
    elif ws.cell(row=1, column=2).value == "年级":
        print("表头已经是 '年级'，跳过重命名")
    else:
        print(f"[WARN] 第 2 列表头为 {ws.cell(row=1, column=2).value!r}，未自动改名")

    stats = {str(v): 0 for v in set(MAP.values())}
    stats["unmapped"] = 0
    unmapped_examples = []

    for r in range(2, ws.max_row + 1):
        v = ws.cell(row=r, column=2).value
        if v is None or str(v).strip() == "":
            continue
        s = str(v).strip()
        if s in MAP:
            new_v = MAP[s]
            ws.cell(row=r, column=2).value = new_v
            stats[str(new_v)] += 1
        else:
            stats["unmapped"] += 1
            if len(unmapped_examples) < 5:
                unmapped_examples.append(s)

    wb.save(INPUT_FILE)
    print(f"\n映射统计: {stats}")
    if unmapped_examples:
        print(f"未识别样例(保留原值): {unmapped_examples}")
    print("保存完成")


if __name__ == "__main__":
    main()