#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""一键顺序执行 01 → 02 → 03"""

import importlib
import sys
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))


def run(name):
    mod = importlib.import_module(name)
    mod.main()


if __name__ == "__main__":
    print("\n>>> Step 1: 字段标准化 + 合并")
    run("01_clean_and_merge")
    print("\n>>> Step 2: 年级映射成编号")
    run("02_grade_to_code")
    print("\n>>> Step 3: 主表校验码回填")
    run("03_backfill_check_code")
    print("\n✓ 全部完成")