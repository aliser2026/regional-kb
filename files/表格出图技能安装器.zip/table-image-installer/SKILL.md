---
name: table-image-installer
version: 1.0.0
description: >-
  当用户在对话中输入「skill」「安装技能」「技能包」「学会技能」并希望安装
  「表格转图片」能力时使用。加载本技能后，把内嵌的 render.py 与表格技能 SKILL.md
  原样写到用户本机的 ~/.workbuddy/skills/excel-table-image/ 完成安装。安装后，
  用户上传 Excel（含学校/年级/班级/人数列）+ 一张样式参考图，输入「数据」即可自动出图。
triggers:
  - skill
  - 安装技能
  - 技能包
  - 学会技能
  - 安装表格技能
---

# 表格转图片 · 安装器技能

本技能的唯一作用：把「表格转图片（excel-table-image）」技能包一次性装到本机，
装好后团队成员无需再管脚本，直接上传 Excel + 样式图、说「数据」就能出图。

## 执行步骤（Agent 照做，不要改动内嵌代码）

1. 确认目标目录存在，不存在则创建：
   `~/.workbuddy/skills/excel-table-image/`
   （macOS/Linux 用 `mkdir -p`；Windows 用 `mkdir`）
2. 用 **Write 工具** 把下面的 **render.py** 代码块 **原样** 写入
   `~/.workbuddy/skills/excel-table-image/render.py`（一个字都不要改）。
3. 用 **Write 工具** 把下面的 **SKILL.md** 代码块 **原样** 写入
   `~/.workbuddy/skills/excel-table-image/SKILL.md`（一个字都不要改）。
4. 写入后，做**安装自检（必须执行，确保团队装完即用）**：
   a) 用 Python 在临时目录现场写一份最小示例 Excel（2 个学校 × 各 2 个年级 × 各 1–2 个班级，
      列名：学校/年级/班级/参与人数，含至少一个值=1 的班），存为 `示例_自检.xlsx`。
   b) 运行：`python3 <技能目录>/render.py --input 示例_自检.xlsx --metric 参与人数 --exclude-value 1`
   c) 检查技能目录（或指定输出目录）是否成功产出 `<学校A>.png`、`<学校B>.png`（剔除值=1 的班后仍有图）。
      成功则自检通过；失败则把报错回显给用户并提示先 `python3 -m pip install openpyxl Pillow`。
   d) 删除临时示例文件和自检产出的 PNG，不留垃圾。
5. 向用户确认安装完成：
   「✅ 已安装『表格转图片』技能（已自动验证可用）。现在把 Excel（含学校/年级/班级/人数列）
   + 一张表格样式图发给我，输入『数据』即可自动生成每校一张的表格图。」

> 两个文件写完后，本技能使命结束，后续出图由 excel-table-image 技能接管。

---

## render.py（原样写入 render.py）

```python
# -*- coding: utf-8 -*-
"""
表格转图片渲染器 v1.0
把「学校 / 年级 / 班级 / 指标」结构的 Excel 渲染成表格图片（参考领课/数独表样式）。

特性：
- 学校列：整列合并，校名垂直居中
- 年级列：按年级合并
- 班级、指标：逐行
- 可剔除「指标值 == 某数」的班级（如 --exclude-value 1 剔除参与人数=1 的班级）
- 每个学校输出一张 PNG，文件名直接用学校名

用法：
  python3 render.py --input 表格.xlsx --metric 参与人数 --exclude-value 1
  python3 render.py --input 表格.xlsx --metric 领课人数          # 不剔除
  python3 render.py --input 表格.xlsx --metric auto --output-dir ./out
"""
import argparse
import os
import sys
from collections import defaultdict

import openpyxl
from PIL import Image, ImageDraw, ImageFont


def find_font():
    """返回系统中可用的中文字体路径，找不到返回 None。"""
    candidates = [
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/System/Library/Fonts/Supplemental/Songti.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "C:/Windows/Fonts/msyh.ttc",
    ]
    for f in candidates:
        if os.path.exists(f):
            return f
    return None


def detect_col(headers, *kw):
    """在表头里按关键词匹配列，返回 0-based 索引；找不到返回 None。"""
    for i, h in enumerate(headers):
        if h is None:
            continue
        hs = str(h)
        for k in kw:
            if k in hs:
                return i
    return None


# 指标列的识别优先级：数字越小越优先（避免「新增人数」误选中）
METRIC_PRIORITY = {
    "领课人数": 1, "报名人数": 2, "零元人数": 3, "参与人数": 4,
    "新增人数": 5, "领课订单数": 6, "人数": 7,
}


def detect_metric_col(headers):
    """在所有表头中按优先级挑出最像『指标人数』的列，返回 0-based 索引。"""
    best, best_p = None, None
    for i, h in enumerate(headers):
        if h is None:
            continue
        hs = str(h)
        for name, p in METRIC_PRIORITY.items():
            if name in hs:
                if best_p is None or p < best_p:
                    best, best_p = i, p
                break
    return best


def render(data, out_path, metric, font_path):
    """data: [(学校, 年级, [(班级, 值), ...]), ...]，每个元素已按学校分组。"""
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    COL_W = [330, 130, 170, 230]   # 学校 年级 班级 指标
    ROW_H = 40
    HEADER_H = 44
    MARGIN = 20

    # 列名映射：把表头「学校/年级/班级/指标」固定为四列，实际字体加载
    f_header = ImageFont.truetype(font_path, 22, index=0)
    f_cell = ImageFont.truetype(font_path, 20, index=0)
    f_school = ImageFont.truetype(font_path, 22, index=0)

    n_rows = sum(len(g[2]) for g in data) + 1  # + 表头
    W = MARGIN * 2 + sum(COL_W)
    H = MARGIN * 2 + HEADER_H + (n_rows - 1) * ROW_H
    img = Image.new("RGB", (W, H), WHITE)
    d = ImageDraw.Draw(img)

    x0 = MARGIN
    y0 = MARGIN
    xs = [x0]
    for w in COL_W:
        xs.append(xs[-1] + w)
    ys = [y0, y0 + HEADER_H]
    for _ in range(n_rows - 1):
        ys.append(ys[-1] + ROW_H)

    # 表头
    headers = ["学校", "年级", "班级", metric]
    for c, htxt in enumerate(headers):
        cx = (xs[c] + xs[c + 1]) / 2
        cy = (ys[0] + ys[1]) / 2
        bb = d.textbbox((0, 0), htxt, font=f_header)
        d.text((cx - (bb[2] - bb[0]) / 2, cy - (bb[3] - bb[1]) / 2 - bb[1]),
               htxt, font=f_header, fill=BLACK)

    # 数据行 + 年级合并
    r = 1
    grade_spans = []
    for _, grade, classes in data:
        start = r
        for cls, val in classes:
            cx = (xs[2] + xs[3]) / 2
            cy = (ys[r] + ys[r + 1]) / 2
            t = str(cls)
            bb = d.textbbox((0, 0), t, font=f_cell)
            d.text((cx - (bb[2] - bb[0]) / 2, cy - (bb[3] - bb[1]) / 2 - bb[1]),
                   t, font=f_cell, fill=BLACK)
            cx = (xs[3] + xs[4]) / 2
            t = str(val)
            bb = d.textbbox((0, 0), t, font=f_cell)
            d.text((cx - (bb[2] - bb[0]) / 2, cy - (bb[3] - bb[1]) / 2 - bb[1]),
                   t, font=f_cell, fill=BLACK)
            r += 1
        grade_spans.append((grade, start, r - 1))

    # 年级文字（垂直居中于合并区）
    for grade, s, e in grade_spans:
        cy = (ys[s] + ys[e + 1]) / 2
        t = str(grade)
        bb = d.textbbox((0, 0), t, font=f_cell)
        cx = (xs[1] + xs[2]) / 2
        d.text((cx - (bb[2] - bb[0]) / 2, cy - (bb[3] - bb[1]) / 2 - bb[1]),
               t, font=f_cell, fill=BLACK)

    # 学校文字（整表垂直居中）
    school = data[0][0]
    total_h = ys[-1] - ys[1]
    cy = ys[1] + total_h / 2
    bb = d.textbbox((0, 0), school, font=f_school)
    cx = (xs[0] + xs[1]) / 2
    d.text((cx - (bb[2] - bb[0]) / 2, cy - (bb[3] - bb[1]) / 2 - bb[1]),
           school, font=f_school, fill=BLACK)

    # 网格线
    for x in xs:
        d.line([(x, ys[0]), (x, ys[-1])], fill=BLACK, width=2)
    d.line([(xs[0], ys[0]), (xs[-1], ys[0])], fill=BLACK, width=2)
    d.line([(xs[0], ys[1]), (xs[-1], ys[1])], fill=BLACK, width=2)
    d.line([(xs[0], ys[-1]), (xs[-1], ys[-1])], fill=BLACK, width=2)
    for k in range(2, n_rows):
        d.line([(xs[2], ys[k]), (xs[-1], ys[k])], fill=BLACK, width=2)
    for grade, s, e in grade_spans:
        d.line([(xs[1], ys[s]), (xs[2], ys[s])], fill=BLACK, width=2)

    img.save(out_path)
    print("saved:", out_path, img.size)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True, help="Excel 文件路径")
    p.add_argument("--output-dir", default=None, help="输出目录，默认与 Excel 同目录")
    p.add_argument("--metric", default="auto",
                   help="第4列指标列名，auto=自动识别(参与人数/领课人数/新增人数/报名人数/零元人数)")
    p.add_argument("--exclude-value", type=int, default=None,
                   help="剔除指标值等于该数的班级（如 1 表示剔除参与人数=1 的班级）")
    args = p.parse_args()

    out_dir = args.output_dir or os.path.dirname(os.path.abspath(args.input))
    os.makedirs(out_dir, exist_ok=True)

    font_path = find_font()
    if font_path is None:
        print("ERROR：未找到中文字体，请安装 CJK 字体（如文泉驿、Noto Sans CJK）。")
        sys.exit(3)

    wb = openpyxl.load_workbook(args.input, data_only=True)
    ws = wb[wb.sheetnames[0]]
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]

    i_school = detect_col(headers, "学校", "校名", "学校名称")
    i_grade = detect_col(headers, "年级")
    i_class = detect_col(headers, "班级", "班")
    if args.metric == "auto":
        i_metric = detect_metric_col(headers)
        metric_name = str(headers[i_metric]) if i_metric is not None else "人数"
    else:
        i_metric = detect_col(headers, args.metric)
        if i_metric is None:  # 显示名与列名不一致时，按优先级回退识别指标列
            i_metric = detect_metric_col(headers)
        metric_name = args.metric  # 图上仍显示用户指定的名字

    if None in (i_school, i_grade, i_class, i_metric):
        print("ERROR 列识别失败：学校=%s 年级=%s 班级=%s 指标=%s" %
              (i_school, i_grade, i_class, i_metric))
        print("实际表头：", headers)
        sys.exit(2)

    data = defaultdict(lambda: defaultdict(list))
    for r in range(2, ws.max_row + 1):
        school = ws.cell(r, i_school + 1).value
        grade = ws.cell(r, i_grade + 1).value
        cls = ws.cell(r, i_class + 1).value
        val = ws.cell(r, i_metric + 1).value
        if school is None or grade is None:
            continue
        try:
            val = int(val)
        except (TypeError, ValueError):
            val = 0 if val is None else val
        if args.exclude_value is not None and val == args.exclude_value:
            continue
        data[school][grade].append((cls, val))

    if not data:
        print("ERROR：无有效数据，请检查 Excel 内容。")
        sys.exit(2)

    for school, grades in data.items():
        rows = [(school, g, [(c, v) for c, v in grades[g]]) for g in sorted(grades.keys())]
        rows = [x for x in rows if x[2]]  # 跳过整年级为空
        out = os.path.join(out_dir, f"{school}.png")
        render(rows, out, metric_name, font_path)


if __name__ == "__main__":
    main()
```

---

## SKILL.md（原样写入 excel-table-image/SKILL.md）

```markdown
---
name: excel-table-image
version: 1.0.0
description: >-
  把 Excel 表格按「参考图片样式」渲染成合并单元格的表格图片。当用户上传一份 Excel
  （含 学校/年级/班级/某指标 列）+ 一张表格样式参考图，并要求「生成表格图 / 按图片样式整理 /
  转成图片 / 数据」时使用。每个学校输出一张 PNG，文件名用学校名；支持剔除指标值等于某数的班级。
  典型场景：领课链接数据、数独报名数据、零元人数等，整理成可转发给老师/家长的图片。
triggers:
  - 生成表格图
  - 按图片样式整理
  - 表格转图片
  - 上传表格+图片样式
  - 数据
---

# 表格转图片技能（excel-table-image）

## 适用场景
团队人员手上有一份 Excel（每行一条「学校 / 年级 / 班级 / 指标值」记录）和一张期望的
表格样式参考图（学校列整列合并、年级列按年级合并、班级逐行、最后一列是指标）。
他们想要：把数据按参考样式渲染成清晰的表格图片，每个学校一张图，方便发群里/发家长。

## 输入
- 一份 Excel（.xlsx），至少含列：学校、年级、班级、指标（指标列名可任意，如 参与人数/领课人数/新增人数/报名人数/零元人数）
- 一张参考样式图（仅用于确认版式，本技能已内置对应渲染逻辑，不强制读取像素）
- 一句口令（见文末「团队口令」）

## 执行步骤（Agent 照做）
1. 确认指标列名：看 Excel 表头，确定第 4 列叫什么（参与人数 / 领课人数 / 其他）。若用户已说明，直接用；否则按表头自动识别。
2. 确认是否剔除：用户若说「剔除参与人数=1 的班级」之类，记下要剔除的指标值（如 1）；未说明则不剔除。
3. 运行渲染脚本（本技能自带 render.py）：
   确保依赖已装：python3 -m pip install --quiet openpyxl Pillow
   命令：python3 <skill目录>/render.py --input "<Excel路径>" --metric <指标列名> [--exclude-value 1]
   例（剔除参与人数=1）：python3 <skill目录>/render.py --input "/桌面/领课链接数据导出 1.xlsx" --metric 参与人数 --exclude-value 1
4. 交付：脚本会在 Excel 同目录下生成「<学校名>.png」（每个学校一张）。用 present_files 把生成的 PNG 一次性展示给用户。

## 渲染规则（已固化在 render.py，无需 Agent 再调）
- 列固定为四列：学校 | 年级 | 班级 | 指标
- 学校列：整列合并，校名垂直居中
- 年级列：相同年级的单元格合并，年级号居中
- 班级、指标列：逐行
- 指标值等于 --exclude-value 的班级整行剔除；剔除后整年级为空的，跳过该年级
- 每行高 40px，表头 44px；黑色网格线、白底

## 可配置项
--metric：第4列指标列名，auto=自动识别（默认 auto）
--exclude-value N：剔除指标值==N 的班级（默认不剔除）
--output-dir：输出目录（默认 Excel 同目录）

## 团队口令（直接复制给用户）
把这份 Excel 和参考样式图发给我，说「数据」即可，我会按图片样式把每个学校生成一张表格图，
文件名用学校名；若某班指标为 1 的班级要剔除，提前说一声。

## 注意事项
- 列名尽量含「学校/年级/班级/人数」字样，识别最稳；若列名特殊，Agent 会按实际表头适配或询问。
- 中文环境需 CJK 字体（macOS 自带 Hiragino/PingFang；Linux 需装 wqy 或 Noto CJK；Windows 用微软雅黑）。
- 多个学校会生成多张图，present_files 可一次全部展示。
```
