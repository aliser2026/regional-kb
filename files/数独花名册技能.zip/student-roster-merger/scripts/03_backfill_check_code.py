#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Step 3: 主表校验码回填到各分表

匹配 key = (学校, 姓名)，同名学生在不同学校不会冲突。
"""

import os
from openpyxl import load_workbook

# ============ 配置区 ============
INPUT_DIR = r"待处理文件夹路径"

# 主表（含 班级 / 姓名 / 校验码 列）
MASTER_FILE = r"主表.xlsx"

# 待回填的分表清单
TARGET_FILES = [
    "学校A_合并排名.xlsx",
    "学校B_合并排名.xlsx",
    # ...
]


def build_mapping():
    wb = load_workbook(MASTER_FILE, data_only=True)
    ws = wb.active
    headers = [ws.cell(row=1, column=c).value for c in range(1, ws.max_column + 1)]

    # 自动定位关键列
    class_col = headers.index("班级") + 1
    name_col = headers.index("姓名") + 1
    code_col = headers.index("校验码") + 1

    m = {}
    for r in range(2, ws.max_row + 1):
        school = ws.cell(row=r, column=class_col).value
        name = ws.cell(row=r, column=name_col).value
        code = ws.cell(row=r, column=code_col).value
        if not name or not code:
            continue
        key = (str(school).strip() if school else "", str(name).strip())
        m[key] = str(code).strip()
    return m


def fill_one(path, mapping):
    wb = load_workbook(path)
    ws = wb.active
    headers = [ws.cell(row=1, column=c).value for c in range(1, ws.max_column + 1)]

    # 找 / 新增"校验码"列
    if "校验码" in headers:
        code_idx = headers.index("校验码") + 1
    else:
        code_idx = ws.max_column + 1
        ws.cell(row=1, column=code_idx).value = "校验码"

    school_idx = headers.index("学校名称") + 1 if "学校名称" in headers else 1
    name_idx = headers.index("学生姓名") + 1 if "学生姓名" in headers else 3

    hit = miss = 0
    miss_examples = []
    for r in range(2, ws.max_row + 1):
        school = ws.cell(row=r, column=school_idx).value
        name = ws.cell(row=r, column=name_idx).value
        if name is None or str(name).strip() == "":
            continue
        key = (str(school).strip() if school else "", str(name).strip())
        if key in mapping:
            ws.cell(row=r, column=code_idx).value = mapping[key]
            hit += 1
        else:
            miss += 1
            if len(miss_examples) < 5:
                miss_examples.append(key)
    wb.save(path)
    return hit, miss, miss_examples


def main():
    if not os.path.isfile(MASTER_FILE):
        print(f"[ERROR] 主表不存在: {MASTER_FILE}")
        return
    mapping = build_mapping()
    print(f"主表映射构建完成：{len(mapping)} 条\n" + "=" * 70)

    total_hit = total_miss = 0
    for i, fname in enumerate(TARGET_FILES, 1):
        fp = os.path.join(INPUT_DIR, fname)
        if not os.path.exists(fp):
            print(f"[{i:02d}] ❌ 文件不存在: {fname}")
            continue
        try:
            hit, miss, miss_examples = fill_one(fp, mapping)
            total_hit += hit
            total_miss += miss
            miss_str = f"未匹配{miss}" + (f" 例:{miss_examples[:3]}" if miss else "")
            print(f"[{i:02d}] ✅ {fname[:50]:<55} 命中 {hit:4d} | {miss_str}")
        except Exception as e:
            print(f"[{i:02d}] ❌ {fname[:50]:<55} 错误: {e}")

    print("\n" + "=" * 70)
    print(f"完成：命中 {total_hit} / 未匹配 {total_miss}")
    print("=" * 70)


if __name__ == "__main__":
    main()