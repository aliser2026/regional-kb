#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Step 1: 字段标准化 + 合并多个分表

操作：
  - 保留：学校名称、班级名称（只保留年级）、学生姓名
  - 删除：得分、作答次数、作答天数、用时（毫秒）
  - 输出：INPUT_DIR/数独花名册_合并结果.xlsx
"""

import os
import re
from openpyxl import load_workbook, Workbook

# ============ 配置区 ============
INPUT_DIR = r"待处理文件夹路径"
OUTPUT_FILE = os.path.join(INPUT_DIR, "数独花名册_合并结果.xlsx")

# 年级正则（覆盖小学一年级到高三）
GRADE_RE = re.compile(
    r"(一年级|二年级|三年级|四年级|五年级|六年级"
    r"|七年级|八年级|九年级|初一年级|初二年级|初三年级)"
)

# 待处理文件清单（按需修改）
TARGET_FILES = [
    "学校A_合并排名.xlsx",
    "学校B_合并排名.xlsx",
    # ... 继续添加
]


def normalize_class(raw):
    """'八年级10班' -> '八年级'；找不到年级则保留原值"""
    if raw is None:
        return ""
    s = str(raw).strip()
    m = GRADE_RE.search(s)
    return m.group(1) if m else s


def process_one(path):
    wb = load_workbook(path, data_only=True)
    ws = wb.active
    rows = []
    for r in range(2, ws.max_row + 1):
        school = ws.cell(row=r, column=1).value
        klass = ws.cell(row=r, column=2).value
        name = ws.cell(row=r, column=3).value
        if all(v in (None, "") for v in (school, klass, name)):
            continue
        if name is None or str(name).strip() == "":
            continue
        rows.append((
            str(school).strip() if school else "",
            normalize_class(klass),
            str(name).strip(),
        ))
    return rows


def main():
    if not os.path.isdir(INPUT_DIR):
        print(f"[ERROR] 输入文件夹不存在: {INPUT_DIR}")
        return

    print(f"开始处理 {len(TARGET_FILES)} 个文件\n" + "=" * 70)
    all_rows = []
    summary = []
    for i, fname in enumerate(TARGET_FILES, 1):
        fp = os.path.join(INPUT_DIR, fname)
        if not os.path.exists(fp):
            print(f"[{i:02d}] ❌ 文件不存在: {fname}")
            summary.append((fname, 0, "NOT_FOUND"))
            continue
        try:
            rows = process_one(fp)
            all_rows.extend(rows)
            print(f"[{i:02d}] ✅ {fname[:50]:<55} 数据 {len(rows):4d} 条")
            summary.append((fname, len(rows), "OK"))
        except Exception as e:
            print(f"[{i:02d}] ❌ {fname[:50]:<55} 错误: {e}")
            summary.append((fname, 0, f"ERR:{e}"))

    # 写出
    wb = Workbook()
    ws = wb.active
    ws.title = "合并花名册"
    ws.append(["学校名称", "班级", "学生姓名"])
    for row in all_rows:
        ws.append(row)
    wb.save(OUTPUT_FILE)

    total = len(all_rows)
    ok = sum(1 for s in summary if s[2] == "OK")
    print("\n" + "=" * 70)
    print(f"完成：{ok}/{len(TARGET_FILES)} 文件，总数据 {total} 条")
    print(f"输出：{OUTPUT_FILE}")
    print("=" * 70)


if __name__ == "__main__":
    main()